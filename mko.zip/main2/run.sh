#!/bin/bash
for (( ; ; ))
do
   cd main2
   timeout 3m python main.py
   sleep 10
   cd ..
   python main.py
   sleep 10
done

