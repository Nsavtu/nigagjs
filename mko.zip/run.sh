#!/bin/bash
for (( ; ; ))
do
   cd main2
   timeout $(((RANDOM % $((350 - 118))) + 118))s python main.py
   sleep 10
   cd ..
   python main.py
   sleep 10
done

